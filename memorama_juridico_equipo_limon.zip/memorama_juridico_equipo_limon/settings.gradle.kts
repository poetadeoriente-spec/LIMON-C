rootProject.name = "MemoramaJuridico"
include(":app")

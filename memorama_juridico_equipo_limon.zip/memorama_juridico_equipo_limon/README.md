Proyecto Memorama Jurídico - Equipo Limón

Abre en Android Studio y compila para generar APK.

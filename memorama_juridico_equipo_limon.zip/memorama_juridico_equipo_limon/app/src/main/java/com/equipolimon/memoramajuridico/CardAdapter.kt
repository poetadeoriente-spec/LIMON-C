package com.equipolimon.memoramajuridico

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class CardAdapter(
    private val ctx: Context,
    private var cards: MutableList<Card>,
    private val onChange: () -> Unit
) : RecyclerView.Adapter<CardAdapter.VH>() {

    var firstIndex: Int? = null
    var attempts = 0
    var matchesFound = 0

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.cardImage)
        val txt: TextView = view.findViewById(R.id.cardText)
        val back: CardView = view.findViewById(R.id.cardBack)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_card, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val card = cards[position]
        holder.txt.text = if (card.isFaceUp || card.isMatched) "${card.concept}\nEQUIPO LIMÓN" else ""
        holder.back.visibility = if (card.isFaceUp || card.isMatched) View.GONE else View.VISIBLE
        if (card.isFaceUp || card.isMatched) {
            val resId = ctx.resources.getIdentifier(card.imageName, "drawable", ctx.packageName)
            if (resId != 0) holder.img.setImageResource(resId)
        } else {
            holder.img.setImageDrawable(null)
        }

        holder.itemView.setOnClickListener {
            if (card.isFaceUp || card.isMatched) return@setOnClickListener
            flipCard(holder, position)
        }
    }

    override fun getItemCount(): Int = cards.size

    private fun flipCard(holder: VH, pos: Int) {
        val card = cards[pos]
        card.isFaceUp = true
        notifyItemChanged(pos)

        if (firstIndex == null) {
            firstIndex = pos
        } else {
            attempts++
            val fi = firstIndex!!
            if (cards[fi].imageName == card.imageName) {
                // match
                cards[fi].isMatched = true
                cards[pos].isMatched = true
                matchesFound++
                firstIndex = null
                onChange()
            } else {
                val prev = fi
                firstIndex = null
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    cards[prev].isFaceUp = false
                    cards[pos].isFaceUp = false
                    notifyItemChanged(prev)
                    notifyItemChanged(pos)
                    onChange()
                }, 800)
            }
            onChange()
        }
    }

    fun reset(newCards: MutableList<Card>) {
        cards = newCards
        firstIndex = null
        attempts = 0
        matchesFound = 0
        notifyDataSetChanged()
    }
}

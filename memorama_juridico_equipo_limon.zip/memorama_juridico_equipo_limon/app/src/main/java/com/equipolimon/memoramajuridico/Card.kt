package com.equipolimon.memoramajuridico

data class Card(
    val concept: String,
    val imageName: String,
    var isFaceUp: Boolean = false,
    var isMatched: Boolean = false
)

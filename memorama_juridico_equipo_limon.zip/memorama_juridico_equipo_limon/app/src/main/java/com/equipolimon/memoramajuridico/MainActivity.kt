package com.equipolimon.memoramajuridico

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recycler: RecyclerView
    private lateinit var scoreText: TextView
    private lateinit var restartBtn: Button
    private lateinit var adapter: CardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.recycler)
        scoreText = findViewById(R.id.scoreText)
        restartBtn = findViewById(R.id.restartBtn)

        recycler.layoutManager = GridLayoutManager(this, 5) // 5 columnas -> 8 filas (40 cartas)

        adapter = CardAdapter(this, generateCards()) { updateScore() }
        recycler.adapter = adapter

        restartBtn.setOnClickListener {
            adapter.reset(generateCards())
            updateScore()
        }

        updateScore()
    }

    private fun generateCards(): MutableList<Card> {
        val concepts = listOf(
            "Derecho","Justicia","Norma jurídica","Ley","Constitución","Jurisdicción",
            "Ciudadanía","Igualdad","Democracia","Estado","Libertad","Derechos humanos",
            "Soberanía","Legalidad","Deber","Tribunal","Abogado","Contrato","Propiedad","Responsabilidad"
        )
        val list = mutableListOf<Card>()
        for (s in concepts) {
            list.add(Card(s, "${s.toLowerCase().replace(' ', '_')}"))
            list.add(Card(s, "${s.toLowerCase().replace(' ', '_')}"))
        }
        list.shuffle()
        return list
    }

    private fun updateScore() {
        scoreText.text = "Intentos: ${adapter.attempts}  -  Parejas encontradas: ${adapter.matchesFound}"
        if (adapter.matchesFound == adapter.itemCount / 2) {
            scoreText.text = "¡Ganaste! Intentos: ${adapter.attempts}"
        }
    }
}
